A Pen created at CodePen.io. You can find this one at https://codepen.io/vaughndtaylor/pen/QNYRdb.

 This is fully responsive & mobile friendly YouTube video background scaled with 16/9 aspect ratio. To make this compatible with a CMS, you can pass data attributes into the wrapper tag.

Forked from [Krz Szzz](http://codepen.io/ccrch/)'s Pen [Responsive YouTube video background](http://codepen.io/ccrch/pen/GgPLVW/).