A Pen created at CodePen.io. You can find this one at https://codepen.io/oliviale/pen/YgzNzK.

 Featuring the most amazing things you can find on earth.

Scroll may be a bit janky due to CSS Scroll Snap - not as smooth as I'd thought it'd be but still awesome.

---

Images from pexels.com.