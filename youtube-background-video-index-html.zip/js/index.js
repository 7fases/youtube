$('#video').YTPlayer({
    fitToBackground: true,
    videoId: '-JlcxL2ux_A'
});